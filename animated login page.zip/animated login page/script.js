// Function to display the Registration form with fade effect
function showRegistration() {
    const loginContainer = document.getElementById("login-container");
    loginContainer.classList.remove("slide-in", "zoom-in");
    loginContainer.classList.add("fade-out");

    setTimeout(() => {
        document.getElementById("form-title").textContent = "Register New User";
        document.getElementById("form").innerHTML = `
            <input type="text" id="username" placeholder="Username" required>
            <input type="email" id="email" placeholder="Email" required>
            <input type="password" id="password" placeholder="Password" required>
            <button type="submit" id="submit-btn">Register</button>
        `;
        
        document.getElementById("toggle-button").textContent = "Back to Login";
        document.getElementById("toggle-button").onclick = showLogin;
        
        loginContainer.classList.remove("fade-out");
        loginContainer.classList.add("fade-in");
    }, 600); // Delay to complete fade-out
}

// Function to display the Login form with slide effect
function showLogin() {
    const loginContainer = document.getElementById("login-container");
    loginContainer.classList.remove("fade-in", "zoom-in");
    loginContainer.classList.add("slide-out");

    setTimeout(() => {
        document.getElementById("form-title").textContent = "Login";
        document.getElementById("form").innerHTML = `
            <input type="text" id="username" placeholder="Username" required>
            <input type="password" id="password" placeholder="Password" required>
            <button type="submit" id="submit-btn">Login</button>
            <div class="options">
                <a href="#" onclick="showForgotPassword()">Forgot Password?</a>
            </div>
        `;
        
        document.getElementById("toggle-button").textContent = "Register New User";
        document.getElementById("toggle-button").onclick = showRegistration;
        
        loginContainer.classList.remove("slide-out");
        loginContainer.classList.add("slide-in");
    }, 600); // Delay to complete slide-out
}

// Function to display the Forgot Password form with zoom effect
function showForgotPassword() {
    const loginContainer = document.getElementById("login-container");
    loginContainer.classList.remove("slide-in", "fade-in");
    loginContainer.classList.add("zoom-out");

    setTimeout(() => {
        document.getElementById("form-title").textContent = "Forgot Password";
        document.getElementById("form").innerHTML = `
            <input type="email" id="email" placeholder="Enter your email" required>
            <button type="submit" id="submit-btn">Reset Password</button>
        `;
        
        document.getElementById("toggle-button").textContent = "Back to Login";
        document.getElementById("toggle-button").onclick = showLogin;

        loginContainer.classList.remove("zoom-out");
        loginContainer.classList.add("zoom-in");
    }, 600); // Delay to complete zoom-out
}
